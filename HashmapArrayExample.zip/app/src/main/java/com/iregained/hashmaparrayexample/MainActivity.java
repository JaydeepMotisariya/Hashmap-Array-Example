package com.iregained.hashmaparrayexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    List<ErrorFormat> errorFormats = new ArrayList<>();
    ArrayAdapter adapter;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView=findViewById(R.id.listview);
        errorFormats.add(new ErrorFormat("Device ID", 0x01));
        errorFormats.add(new ErrorFormat("Message ID", 0x01));
        errorFormats.add(new ErrorFormat("Finger Spacing", 0x01));
        errorFormats.add(new ErrorFormat("Thumb X", 0x02));
        errorFormats.add(new ErrorFormat("Thumb Y", 0x02));
        errorFormats.add(new ErrorFormat("Register 1", 0x03));
        errorFormats.add(new ErrorFormat("Register 2", 0x03));
        errorFormats.add(new ErrorFormat("Register 3", 0x03));
        errorFormats.add(new ErrorFormat("Register 4", 0x03));
        errorFormats.add(new ErrorFormat("Register 5", 0x03));
        for (int i = 0; i <errorFormats.size() ; i++) {
            Log.d(TAG, "onCreate: Error Name:" + errorFormats.get(i).getError_name() + " Error Code: " +errorFormats.get(i).getError_code());

        }

    }
}