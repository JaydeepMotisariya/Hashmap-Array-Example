package com.iregained.hashmaparrayexample;

public class ErrorFormat {
    private String error_name;
    private int error_code;

    public ErrorFormat(String error_name, int error_code) {
        this.error_name = error_name;
        this.error_code = error_code;
    }

    public String getError_name() {
        return error_name;
    }

    public void setError_name(String error_name) {
        this.error_name = error_name;
    }

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }
}
